package com.example.etollcollectionmanagementsystem;

public class DriverVehicle {
    private String driverName;
    private String driverLisence;
    private String vehicleNumber;
    private String vehicleModel;
    private String vehicleType;

    public DriverVehicle() {
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getDriverLisence() {
        return driverLisence;
    }

    public void setDriverLisence(String driverLisence) {
        this.driverLisence = driverLisence;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public void setVehicleNumber(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }

    public String getVehicleModel() {
        return vehicleModel;
    }

    public void setVehicleModel(String vehicleModel) {
        this.vehicleModel = vehicleModel;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public DriverVehicle(String driverName, String driverLisence, String vehicleNumber, String vehicleModel, String vehicleType) {
        this.driverName = driverName;
        this.driverLisence = driverLisence;
        this.vehicleNumber = vehicleNumber;
        this.vehicleModel = vehicleModel;
        this.vehicleType = vehicleType;
    }
}
