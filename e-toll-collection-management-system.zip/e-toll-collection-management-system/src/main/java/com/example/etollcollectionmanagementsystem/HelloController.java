package com.example.etollcollectionmanagementsystem;

import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.awt.event.ActionEvent;

public class HelloController {
    @FXML
    private TableColumn<?, ?> dateCol;

    @FXML
    private TableColumn<?, ?> driverLisenceCol;

    @FXML
    private TextField driverLisenceText;

    @FXML
    private TableColumn<?, ?> driverNameCol;

    @FXML
    private TextField driverNameText;

    @FXML
    private DatePicker fromDatePick;

    @FXML
    private DatePicker toDatePick;

    @FXML
    private TableColumn<?, ?> vehicleModelCol;

    @FXML
    private TextField vehicleModelText;

    @FXML
    private TableColumn<?, ?> vehicleNumberCol;

    @FXML
    private TextField vehicleNumberText;

    @FXML
    private TableColumn<?, ?> vehicleTypeCol;

    @FXML
    private ComboBox<?> vehicleTypeCombo;

    @FXML
    public void handlesCollectAction(javafx.event.ActionEvent actionEvent) {
    }

    @FXML
    public void handlesSearchAction(javafx.event.ActionEvent actionEvent) {
    }
}