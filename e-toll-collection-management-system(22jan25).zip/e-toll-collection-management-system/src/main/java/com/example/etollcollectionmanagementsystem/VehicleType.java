package com.example.etollcollectionmanagementsystem;

public class VehicleType {
}
