package com.example.etollcollectionmanagementsystem;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.awt.event.ActionEvent;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class HelloController {
    ObservableList<String> vehicleTypeList = FXCollections.observableArrayList("Car", "Van", "Bus", "Lorry", "Motorbike");
    @FXML
    private TableColumn<DriverVehicle, String> dateCol;

    @FXML
    private TableColumn<DriverVehicle, String> driverLisenceCol;

    @FXML
    private TextField driverLisenceText;

    @FXML
    private TableColumn<DriverVehicle, String> driverNameCol;

    @FXML
    private TextField driverNameText;

    @FXML
    private DatePicker fromDatePick;

    @FXML
    private DatePicker toDatePick;

    @FXML
    private TableColumn<DriverVehicle, String> vehicleModelCol;

    @FXML
    private TextField vehicleModelText;

    @FXML
    private TableColumn<DriverVehicle, String> vehicleNumberCol;

    @FXML
    private TextField vehicleNumberText;

    @FXML
    private TableColumn<DriverVehicle, String> vehicleTypeCol;

    @FXML
    private ComboBox<String> vehicleTypeCombo;

    public void initialize() {
        vehicleTypeCombo.setItems(vehicleTypeList);
    }

    @FXML
    public void handlesCollectAction(javafx.event.ActionEvent actionEvent) {
        String driverName = driverNameText.getText();
        String driverLisence = driverLisenceText.getText();
        String vehicleNumber = vehicleNumberText.getText();
        String vehicleModel = vehicleModelText.getText();
        String vehicleType = vehicleTypeCombo.getValue();

        String insertQuery = "INSERT INTO etoll (driverName, driverLisence, vehicleNumber, vehicleModel, vehicleType) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = DBConnection.getStatement().getConnection().prepareStatement(insertQuery)) {
            preparedStatement.setString(1, driverName);
            preparedStatement.setString(2, driverLisence);
            preparedStatement.setString(3, vehicleNumber);
            preparedStatement.setString(4, vehicleModel);
            preparedStatement.setString(5, vehicleType);
            preparedStatement.executeUpdate();

            System.out.println(driverName + " " + driverLisence + " " + vehicleNumber + " " + vehicleModel + " " + vehicleType);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        driverNameText.clear();
        driverLisenceText.clear();
        vehicleNumberText.clear();
        vehicleModelText.clear();
        vehicleTypeCombo.setValue(null);

    }

    @FXML
    public void handlesSearchAction(javafx.event.ActionEvent actionEvent) {
    }
}